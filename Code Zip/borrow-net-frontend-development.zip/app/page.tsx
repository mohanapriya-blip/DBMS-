import BorrowNetApp from '@/components/borrownet-app'

export default function Page() {
  return <BorrowNetApp />
}
